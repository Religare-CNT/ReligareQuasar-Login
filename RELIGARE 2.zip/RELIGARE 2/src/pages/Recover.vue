<template>
  <div class="padding32" style="max-width: 300px">
      <p style="font-size: 20px "> Recuperar senha </p><hr>
      <p class="marginTop32" style="font-size: 30px">Religare</p>
      <q-input class="marginTop32" filled label="Email"   /><br>
      <q-btn class="width100 marginTop16 marginBottom8" color="primary" label="Recuperar senha"/>
      <span >Já tem conta ? ---</span> <span style="color: #1976D2" @click ="login ()"> Fazer login </span>
      <br>
      <span >Não tem conta ? ---</span> <span style="color: #1976D2" @click ="register ()"> Cadastre-se </span>
  </div>
</template>

<script>
export default {
  name: 'PageIndex',
  methods: {
    login () {
      this.$router.push('/login')
    }
  }
}
