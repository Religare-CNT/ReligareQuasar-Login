/* eslint-disable eol-last */
<template>
  <div class="padding32" style="max-width: 300px">
      <p style="font-size: 30px ">Fazer login </p><hr>
      <q-input class="marginTop32" filled label="Email de login" /><br>
       <q-input type="password"  class="marginTop8"  filled label="Senha" />
       <q-btn @click="login () " class="width100 marginTop8 marginBottom8" color="primary" label="login"/>
       <span  @click ="recover ()" style="color:#1976D2">Recuperar minha senha</span><br>
       <span >Não tem conta ? ---</span> <span style="color: #1976D2" @click ="register ()"> Cadastre-se </span>
  </div>
</template>
<script>
export default {
  name: 'PageIndex',
  methods: {
    login () {
      this.$router.push('/Index')
    },
    recover () {
      this.$router.push('/Recover')
    },
    register () {
      this.$router.push('/register')
    }
  }
}
</script>
