
const routes = [
  {
    path: '/',
    component: () => import('layouts/MainLayout.vue'),
    children: [
      { path: 'index', component: () => import('pages/Index.vue') }
    ]
  },
  {
    name: 'Login',
    path: '/login',
    component: () => import('pages/Login.vue')
  },
  {
    name: ' Register',
    path: '/register',
    component: () => import('pages/Register.vue')
  },
  {
    name: ' Recover',
    path: '/recover',
    component: () => import('pages/Recover.vue')
  },

  // Always leave this as last one,
  // but you can also remove it
  {
    path: '*',
    component: () => import('pages/Error404.vue')
  }
]

export default routes
